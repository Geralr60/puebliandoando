<?php

namespace App\Http\Controllers\Sitio;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PlanesController extends Controller
{
    public function alojamientos(){
        return view('Alojamientos');
    }

    public function recorridos(){
        return view('Recorridos');
    }

    public function tours(){
        return view('Tours');
    }

    public function contacto(){
        return view('Contacto');
    }
}
