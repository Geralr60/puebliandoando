<?php

namespace App\Http\Controllers\Sitio;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class Alojamientos extends Controller
{
    public function alojammiento(){
        $datos['planes'] = [
                            ['Hotel La Bonita',                 'La pintada',           'https://unsplash.com/photos/Bj_rcSC5XfE', 'hotel-nn-en--xx', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '$100000'],
                            ['Hotel Bellavista',                'Amagá',                'https://unsplash.com/photos/Bj_rcSC5XfE', 'hotel-nn-en--xx', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '$100000'],
                            ['Finca Los Girasoles',             'Jardín',               'https://unsplash.com/photos/Bj_rcSC5XfE', 'hotel-nn-en--xx', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '$100000'],
                            ['Finca-Hotel Los Marineros',       'Santa Fe de Antiquia', 'https://unsplash.com/photos/Bj_rcSC5XfE', 'hotel-nn-en--xx', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '$100000'],
                            ['Hotel Campestre El Sol',          'San Jeronimo',         'https://unsplash.com/photos/Bj_rcSC5XfE', 'hotel-nn-en--xx', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '$100000'],   
                           ];
                $datos ['Titulo']='Alojamiento';
    
    return view ('planes', $datos);
}
}
