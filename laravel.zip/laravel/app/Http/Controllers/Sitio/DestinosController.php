<?php

namespace App\Http\Controllers\Sitio;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\Planes;
use Illuminate\Support\Facades\DB;

class DestinosController extends Controller
{
    public function alojamientos() {return $this -> destinos(1, 'Alojamientos'); }
    public function recorridos() {return $this -> destinos(2, 'Recorridos'); }
    public function tours() {return $this -> destinos(3, 'Tours'); }

    public function destinos($Tipo_id = 1){
        $data['query'] = DB::table('destinos')
                        -> join('planes', 'destinos_id', '=', 'planes.destino_id')
                        -> join('tipo', 'planes.tipo_id', "=", 'tipo.id')
                        ->select(
                                        'destinos.titulo AS destino',
                                        'planes.titulo AS nombre',
                                        'planes.url AS Url',
                                        'planes.tipo_id AS tipo_id',
                                        'planes.imagenes AS imagenes',
                                        'planes.valor AS valor',
                                        'planes.slider AS slider',
                                        'planes.calificacion AS calificiacion',
                                        'tipo.url AS tipoUrl',
                                        'tipo.titulo AS tipo')
                        ->where('tipo.id', '=', $Tipo_id)
                        ->get();

        return view('planes', $data);   
    }

    //public fuction alojamientoActual($url){

    //}
}
