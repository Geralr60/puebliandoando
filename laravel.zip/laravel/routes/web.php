<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('theme');
});

Route::get('/Reserva', function () {
    return view('Reserva');
});

/*Route::get('/Alojamientos', function () {
    return view('Alojamientos');
});


Route::get('/Recorridos', function () {
    return view('Recorridos');
});

Route::get('/Tours', function () {
    return view('Tours');
});


Route::get('/Contacto', function () {
    return view('Contacto');
}); */

Route::get('/alfanumerico/{url}', function(){
    return 'alfanumerico :)';
}) -> where(['url' => '[A-Za-z0-9]+']);



Route::get('/numerico/{url}', function(){
    return 'numerico: ';
}) -> where(['url' => '[0-9]+']); 

/*Route::get('/prueba', 'Sitio\Alojamientos@alojammiento');*/

Route::get('/prueba', 'Sitio\Alojamientos@alojammiento');

Route::get('/Alojamientos', 'Sitio\PlanesController@alojamientos');
Route::get('/Alojamientos/[url]', 'Sitio\PlanesController@alojamientosActual') -> where(['url' => '[A-Za-z0-9]+']);



Route::get('/Recorridos', 'Sitio\PlanesController@recorridos');
Route::get('/Recorridos/[url]', 'Sitio\PlanesController@recorridosActual') -> where(['url' => '[A-Za-z0-9]+']);



Route::get('/Tours', 'Sitio\PlanesController@tours');
Route::get('/Tours/[url]', 'Sitio\PlanesController@alojamientosActual') -> where(['url' => '[A-Za-z0-9]+']);



Route::get('/Contacto', 'Sitio\PlanesController@contacto');


Route::get('/Login', function(){return view('auth.login');});


Route::resource('/crud', 'Crud\CrudController');
Route::get('/crud/numerico/{url}', 'Crud\CrudController@numerico') -> where(['url' => '[0-9]+']);


Route::get('/encrypt', 'Crud\CrudController@encrypt1');
Route::get('/decrypt', 'Crud\CrudController@decrypt1');


