<?php $__env->startSection('Content'); ?>
<br>
<a href="<?php echo e(url('crud/create')); ?>" class="btn btn-outline-success"> Nuevo registro </a> <br> <br>

    <?php if(session('msg')): ?>
        <div class="alert <?php echo e(session('class')); ?>">
            <?php echo e(session('msg')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-hover" width=100%>
            <tr>
                <td width="20%">ID</td>
                <td width="20%">NOMBRE</td>
                <td width="20%">&nbsp;</td>
                <td width="20%">&nbsp;</td>
                <td width="20%">&nbsp;</td>
            </tr>
        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($c -> id); ?></td>
                <td> <?php echo e($c -> Nombre); ?></td>
                <td><a href="<?php echo e(url('crud/'.$c -> id)); ?>" class="btn btn-outline-primary"> Ver </a></td>
                <td><a href="<?php echo e(url('crud/'.$c -> id.'/edit')); ?>" class="btn btn-outline-warning"> Actualizar </a></td>
                <td>
                    <form method="POST" action="<?php echo e(url('crud/'.$c->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-danger"> Eliminar </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<br>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantilla2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>