<?php $__env->startSection('Content'); ?>
    <h1> <?php echo e($query -> id); ?> </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantilla2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>