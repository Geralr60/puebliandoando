<?php $__env->startSection('Content'); ?>
    <!-- Cards Alojamiento -->
    <br>
    <h2> Alojamientos </h2>
    <div class="Contenedor">
      <div class="Card">
        <img src="https://source.unsplash.com/xP_AGmeEa6s">
        <h4> La Pintada </h4>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        <br>
        <a class="btn btn-primary" href="/Alojamientos" role="button">Leer más</a>
      </div>

      <div class="Card">
        <img src="https://source.unsplash.com/mpQ6dEm8r7I">
        <h4> Amagá </h4>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        <br>
        <a class="btn btn-primary" href="/Alojamientos" role="button">Leer más</a>
      </div>

      <div class="Card">
        <img src="https://source.unsplash.com/O9GivLXVcMs">
        <h4> Jardín </h4>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        <br>
        <a class="btn btn-primary" href="/Alojamientos" role="button">Leer más</a>
      </div>

      <div class="Card">
        <img src="https://source.unsplash.com/7RQf2X6aXXI">
        <h4> Santa Fe de Antioquia </h4>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        <br>
        <a class="btn btn-primary" href="/Alojamientos" role="button">Leer más</a>
      </div>

      <div class="Card">
        <img src="https://source.unsplash.com/yAUHQVT9X1I">
        <h4> San Jeronimo </h4>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        <br>
        <a class="btn btn-primary" href="/Alojamientos" role="button">Leer más</a>
      </div>
    </div>


    <!-- Carousel Recorridos -->
    <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>
    <div class="Carrousel">
      <h2>Recorridos por las regiones y tours guiados</h2><br>
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="https://source.unsplash.com/0iXc2eDE8Pk/700x400" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Recorrido Medellin - Jardin - Medellin </h5>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis repudiandae nesciunt ex, impedit</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://source.unsplash.com/ioLq-zmtITA/700x400" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Recorrido Medellín - San Jeronimo - Santa Fe de Antioquia - Medellin</h5>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis repudiandae nesciunt ex, impedit</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://source.unsplash.com/QOAKssvAZ_I/700x400" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Recorrido Medellín - Amagá - La pintada - Medellin</h5>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis repudiandae nesciunt ex, impedit</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://source.unsplash.com/ioYwosPYC0U/700x400" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Toures</h5>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis repudiandae nesciunt ex, impedit</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
        <br>
      </div>
      <div class="btn-group">
          <a href="/Recorridos" class="btn btn-success me-md-2 active" aria-current="page">Recorridos</a>
          <a href="/Tours" class="btn btn-success me-md-2" >Tours</a>
        </div>
    </div>
    <br> <br>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>