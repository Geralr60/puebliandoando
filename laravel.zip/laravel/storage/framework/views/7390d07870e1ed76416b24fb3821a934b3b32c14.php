<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">


    <title>Tema uno</title>
  </head>
  <body>
      <ul>
      <li><a href="/planes"> Planes </a> </li>
        <li><a href="/"> Inicio </a> </li>
        <li><a href="/cliente"> Contacto </a> </li>
        <li><a href="/reserva">Reservas </a>  </li>
        <li><a href="/destinos">Destinos </a>  </li>
      </ul>
    <h1> Planes </h1>
    
  </body>
</html>