<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Tema uno</title>
  </head>
  <body>
      <ul>
          <li><a href="<?php echo e(url('planes')); ?>"> Planes </a></li>
          <li><a href="<?php echo e(url('/')); ?>">Inicio</a> </li>
          <li><a href="<?php echo e(url('/contacto')); ?>">Contacto</a> </li>
      </ul>
    <h1> Contacto </h1>
    
  </body>
</html>