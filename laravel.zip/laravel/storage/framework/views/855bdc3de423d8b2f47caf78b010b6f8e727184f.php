<?php $__env->startSection('Content'); ?>

<br>
    <form action="<?php echo e(url('/crud/'.$query -> id)); ?>" method="POST">
        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?> ">
        <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="txtDestino" class="form-label">Nuevo destino</label>
                <input type="text" class="form-control" id="txtDestino" name="txtDestino" placeholder="Ingrese un nuevo destino" value="<?php echo e($query -> Nombre); ?>">
            </div>
            <button type="submit" class="btn btn-success"> Submit</button>
    </form>
    <br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantilla2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>