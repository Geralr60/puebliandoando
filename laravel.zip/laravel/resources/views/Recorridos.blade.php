@extends('plantilla')

@section('Content')
  <br>  


  <br>
@endsection