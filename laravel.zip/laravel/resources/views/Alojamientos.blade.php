@extends('Plantilla2')

@section('Content')
  <br>  
    <table class="table table-dark table-hover ">
      <tr>
        <th></th>
        <th> Descripción</th>
        <th>Precio</th>
        <th></th>
      </tr>
      <tr>
        <td class="TDImagen"> <img src="https://source.unsplash.com/ORS4Y-et7xg/200x200" class="img-fluid" id="img"> </td>
        <td> 
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel laboriosam pariatur nobis aliquam, voluptas veniam quos magni modi id quasi alias provident rem, sit necessitatibus mollitia recusandae molestias nisi officia?
        </td>
        <td> $88.000 por persona </td>
        <td> <a class="btn btn-success" href="/Reserva" role="button"> Reservar ahora </a></td>
      </tr>
      <tr>
      <td class="TDImagen"> <img src="https://source.unsplash.com/ORS4Y-et7xg/200x200" class="img-fluid" id="img">  </td>
        <td> 
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur quisquam cum esse rem doloremque, velit veniam quae harum sint est sunt rerum a voluptas. Voluptatibus numquam blanditiis aut earum quis.
        </td>
        <td> $100.000 por persona </td>
        <td> <a class="btn btn-success" href="/Reserva" role="button"> Reservar ahora </a></td>
      </tr>
      <tr>
      <td class="TDImagen"> <img src="https://source.unsplash.com/ORS4Y-et7xg/200x200" class="img-fluid" id="img">  </td>
        <td> 
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque necessitatibus, asperiores sit voluptatum illum maiores amet pariatur deserunt facilis, dolor, impedit commodi laborum modi a nam recusandae quam assumenda? Rerum.
        </td>
        <td> $100.000 c/u </td>
        <td> <a class="btn btn-success" href="/Reserva" role="button"> Reservar  </a></td>
      </tr>
      <tr>
      <td class="TDImagen"> <img src="https://source.unsplash.com/ORS4Y-et7xg/200x200" class="img-fluid" id="img">  </td>
        <td> 
          La Pintada <br>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit, consequuntur repudiandae nisi temporibus obcaecati, cum soluta illum perferendis, quae porro voluptates qui esse adipisci deleniti? Voluptates id ad maxime neque!
        </td>
        <td> $100.000 por persona </td>
        <td> <a class="btn btn-success" href="/Reserva" role="button"> Reservar ahora </a></td>
      </tr>
      <tr>
      <td class="TDImagen"> <img src="https://source.unsplash.com/jIJuwlQHou8/200x200" class="img-fluid" id="img">  </td>
        <td> 
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut fugiat illo adipisci earum, non labore nobis enim repellat aspernatur delectus pariatur temporibus, totam autem ipsum deserunt, architecto quidem neque debitis!
        </td>
        <td> $100.000 por persona </td>
        <td> <a class="btn btn-success" href="/Reserva" role="button"> Reservar ahora </a></td>
      </tr>
      <tr>
      <td class="TDImagen"> <img src="https://source.unsplash.com/ORS4Y-et7xg/200x200" class="img-fluid" id="img">  </td>
        <td> 
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis, cumque deserunt beatae autem quasi ducimus totam provident non rerum nulla saepe facilis suscipit cum enim. Deleniti repudiandae molestiae voluptatum nostrum?
        </td>
        <td> $100.000 por persona </td>
        <td> <a class="btn btn-success" href="/Reserva" role="button"> Reservar ahora </a></td>
      </tr>
    </table>
  <br>
@endsection