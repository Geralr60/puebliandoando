<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="css/Reset.css"> 
    <link rel="stylesheet" href="css/Styles.css"> 
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">

    <title>Puebliando ando </title>

  </head>
  <body>

  <!-- Cabecera (Menú principal) -->
  <header class="Main-header">
    <nav class="main-nav">
      <div class="logo">
      <img src="https://img.icons8.com/cotton/64/000000/tourist-backpack--v1.png"></a> 
      </div>
      <ul class="Menu">
        <li><a href="/"> Inicio </a> </li>
        <li><a href="/Alojamientos"> Alojamientos </a> </li>
        <li><a href="/Recorridos"> Recorridos </a> </li>
        <li><a href="/Tours">Tours </a>  </li>
        <li><a href="/Contacto">Contacto </a>  </li>
      </ul>
    </nav>
    <div class="Content-header">
        <h1> Puebliando ando </h1>
        <p> Seamos testigos de las maravillas de Antioquia </p>
      </div>
  </header>


  <div class="container">
    @yield('Content')
  </div>

   <!-- Pie de pagina -->
  <div class="ContenedorP">
      <footer>
        <p> Geraldin Rodriguez Muriel - Vanessa Betancur Gil</p>
        <P> 2021 </p>
      </footer>
  </div>
  

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
  </body>
</html>