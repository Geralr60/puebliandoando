@extends('Plantilla2')

@section('Content')
<br>
<a href="{{ url('crud/create')}}" class="btn btn-outline-success"> Nuevo registro </a> <br> <br>

    @if (session('msg'))
        <div class="alert {{session('class')}}">
            {{session('msg')}}
        </div>
    @endif

    <table class="table table-hover" width=100%>
            <tr>
                <td width="20%">ID</td>
                <td width="20%">NOMBRE</td>
                <td width="20%">&nbsp;</td>
                <td width="20%">&nbsp;</td>
                <td width="20%">&nbsp;</td>
            </tr>
        @foreach($query AS $c)
            <tr>
                <td> {{ $c -> id }}</td>
                <td> {{ $c -> Nombre }}</td>
                <td><a href="{{ url('crud/'.$c -> id) }}" class="btn btn-outline-primary"> Ver </a></td>
                <td><a href="{{ url('crud/'.$c -> id.'/edit') }}" class="btn btn-outline-warning"> Actualizar </a></td>
                <td>
                    <form method="POST" action="{{ url('crud/'.$c->id) }}">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-outline-danger"> Eliminar </button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
<br>



@endsection