@extends('Plantilla2')

@section('Content')
    <h1> {{$query -> id}} </h1>
@endsection