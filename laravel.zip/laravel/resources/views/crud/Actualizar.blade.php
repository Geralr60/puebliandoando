@extends('Plantilla2')

@section('Content')

<br>
    <form action="{{ url('/crud/'.$query -> id) }}" method="POST">
        <input name="_token" type="hidden" value="{{ csrf_token() }} ">
        @method('PUT')
            <div class="mb-3">
                <label for="txtDestino" class="form-label">Actualizar destino</label>
                <input type="text" class="form-control" id="txtDestino" name="txtDestino" placeholder="Ingrese la actualización del destino" value="{{ $query -> Nombre }}">
            </div>
            <button type="submit" class="btn btn-success"> Submit</button>
    </form>
    <br>

@endsection