@extends('Plantilla2')

@section('Content')
    <br>
    <form action="{{ url('/crud') }}" method="POST">
        <input name="_token" type="hidden" value="{{ csrf_token() }} ">
            <div class="mb-3">
                <label for="txtDestino" class="form-label">Nuevo destino</label>
                <input type="text" class="form-control" id="txtDestino" name="txtDestino" placeholder="Ingrese un nuevo destino">
            </div>
            <button type="submit" class="btn btn-success"> Submit</button>
    </form>
    <br>
@endsection