@extends('Plantilla2')

<?php
    $imagenes = json_decode($query[0] -> imagenes);
    $imagen = [];
    if (isset($imagenes -> photos) && count($imagenes -> photos) >0):
        $imagen = $imagenes -> photos;
    endif;

    $titulo = $query[0] -> plan;
    $destino = $query[0] -> destino;
    $descripcion = $query[0] -> descripcion;

    $array = [
        [7, '07:00 A.M.'], 
        [8, '08:00 A.M.'], 
        [9, '09:00 A.M.'], 
        [10, '10:00 A.M.'], 
        [11, '11:00 A.M.'], 
        [12, '12:00 M.'], 
        [13, '01:00 P.M.'], 
        [14, '02:00 P.M.'], 
        [15, '03:00 P.M.'], 
        [16, '04:00 P.M.'], 
        [17, '05:00 P.M.'], 
        [18, '06:00 P.M.'], 
        [19, '07:00 P.M.'], 
        [20, '08:00 P.M.']
    ];

    $time = [];

    $currentDate = new DateTime();
    $currentDate -> modify('+4 hours');
    $currentDate = (int)$currentDate->format('G');

    foreach($array AS $c):
        if($c[0] >= $currentTime):
            array_push($time, [$c[0], $c[1]]);
        endif;
    endforeach;

    

